#format

a=4
b=8
c=a+b
print('addition of{0}and{1}is{2}'.format(a,b,c))
