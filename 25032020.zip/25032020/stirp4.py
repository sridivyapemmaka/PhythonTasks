a="PythoN"

print(a.find("z"))
print(a.find("Pz"))
print(a.find("yt"))
print(a.find("px"))
print(a.find("oz"))
