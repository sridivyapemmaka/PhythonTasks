a="python"

print(a.find("t"))
print(a.find("on"))
print(a.find("n"))
print(a.find("th"))
print(a.find("y"))
print(a.find("py"))
print(a.find("z"))
