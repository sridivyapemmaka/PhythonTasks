#capitalize

a="sridivya"
b=a.capitalize()
print(b)

a="computer science"
b=a.capitalize()
print(b)

