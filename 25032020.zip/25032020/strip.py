#stip

a="python"
b=a.strip("-")
print(b)


a="java"
b=a.strip()
print(b)
