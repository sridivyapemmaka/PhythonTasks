#isalnum()
a="hello"
b=a.isalnum()
print(b)

#isalpha()
a="divya"
b=a.isalpha()
print(b)

#isdecimal()
a="10"
b=a.isdecimal()
print(b)

#isdigit()
a="123456789"
b=a.isdigit()
print(b)

#isidentifier()
a="divya"
b=a.isidentifier()
print(b)

#islower()
a="sridivya"
b=a.lower()
print(b)

#isnumeric()
a="123456"
b=a.isnumeric()
print(b)

#isprintable()
a="hello\h welcome to hello world"
b=a.isprintable()
print(b)

#isspace
a="    "
b=a.isspace()
print(b)

#istitle()
a="HELLO"
b=a.istitle()
print(b)

#isupper()
a="sridivya"
b=a.isupper()
print(b)

#join()
a=["Welcome", "To" ,"Hello", "world"]
b=a.join()
print(b)

#1just()
a="divya"
b=a.Ijust(7),"loves python programming"
print(b)

