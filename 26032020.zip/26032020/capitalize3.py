#lower
a="SRIDIVYA"
b=a.lower()
print(b)

#Istrip()
a="-divya"
b=a.strip()
print(b)

#partition
a="Hello World"
b=a.partition('World')
print(b)

#repalce()
a="sridivya"
b=a.replace("s","d")
print(b)

#rfind()
a="divya"
b=a.rfind("d")
print(b)

#rindex()
a="Divya"
b=a.rindex(D)
print(b)

#rjust()
a="divya"
b=a.rjust(10)
print(b)

#rpartition()
a="i am sridivya"
b=a.rpartition("am")
print(b)

#rsplit
a="iam a girl"
b=a.rsplit(" ")
print(b)

#rstrip
a="divya-"
b=a.rstrip("-")
print()
