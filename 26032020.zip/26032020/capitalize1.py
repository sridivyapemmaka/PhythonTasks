#capitalize()   (converts the first charecter to upper case_
a="sridivya"
b=a.capitalize()
print(b)

#case fold()  (converts string into lower case)
a="DIVYA"
b=a.capitalize()
print(b)

#center()     (returns center string)
a="sridivya"
b=a.center(12)
print(b)

#count()      (return num of times specified value in a string)
a="sridivya"
b=a.count("s")
print(b)

#encode  (returns encoded version of the string,returns binary value on a string)
a="hello"
b=a.encode()
print(b)

#end swith
a="divya"
b=a.endswith("d")
print(b)

#expandtabs
a="D/ti/tv/ty/ta"
b=a.expandtabs(5)
print(b)

#find
a="divya"
b=a.find("d")
print(b)

#index
a="divya"
b=a.index("v")
print(b)
