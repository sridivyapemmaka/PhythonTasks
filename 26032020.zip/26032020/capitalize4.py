#strip()
a="   Divya   "
b=a.strip(" ")
print(b)

#swapcase()
a="I am divya"
b=a.swapspace()
print(b)

#title()
a="Hello World"
b=a.tittle()
print(b)

#upper()
a="sridivya"
b=a.upper()
print(b)

#zfill()
a="Hello World"
b=a.zfill(12)
print(b)
