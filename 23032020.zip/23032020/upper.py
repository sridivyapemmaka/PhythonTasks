#upper
a="python"
b=a.upper()
print(b)
c="java"
d=c.lower()
print(d)
