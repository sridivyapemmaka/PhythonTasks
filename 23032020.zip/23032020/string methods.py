a="python"
print(a)
print(type(a))
print(len(a))
