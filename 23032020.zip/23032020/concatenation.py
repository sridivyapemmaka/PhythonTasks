#concatenation
a=4
b=6
c=a+b
print(c)
print(a+b)
