#upper
a="PythoN"
b=a.upper()
print(b)
c="java"
d=c.lower()
print(d)
