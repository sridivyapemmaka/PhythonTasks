a=True
b=float(a)
print(a)
print(b)
print(type(a))
print(type(b))

a=()
b=int(a)
print(a)
print(b)
print(type(a))
print(type(b))
