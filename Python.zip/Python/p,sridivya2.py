a="7"
b=float(a)
print(a)
print(b)
print(type(a))
print(type(b))

a="7"
b=bool(a)
print(a)
print(b)
print(type(a))
print(type(b))

a=True
b=string(a)
print(a)
print(b)
print(type(a))
print(type(b))

