r=9.2
h=3
pi=3.14
Volume=int(0.3*pi*r*r*h)
print("Volume of cone=",Volume)


n=5
p=5*365
r=3.2
Output=float(n*p*r)
print("Output of npr=",Output)
