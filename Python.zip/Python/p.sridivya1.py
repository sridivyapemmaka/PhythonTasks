a=7
b=float(a)
print(a)
print(b)
print(type(a))
print(type(b))

a=True
b=bool(a)
print(a)
print(b)
print(type(a))
print(type(b))

a=7
b=bool(a)
print(a)
print(b)
print(type(a))
print(type(b))

a="7"
b=int(a)
print(a)
print(b)
print(type(a))
print(type(b))

a="7"
b=string(a)
print(a)
print(b)
print(type(a))
print(type(b))

a="7"
b=float(a)
print(a)
print(b)
print(type(a))
print(type(b))



































